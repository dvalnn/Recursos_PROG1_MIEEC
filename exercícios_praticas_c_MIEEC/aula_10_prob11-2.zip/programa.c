#include <stdio.h>
#include "datas.h"

int main(void) {

  /* ler data
     validar data
     ler número de dias a avançar
     actualizar data
     imprimir data actualizada */

}
